import streamlit as st
import pickle
import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# === Load Models & Vectorizer ===
with open("best_nb.pkl", "rb") as f:
    best_nb = pickle.load(f)

with open("best_lr.pkl", "rb") as f:
    best_lr = pickle.load(f)

with open("ensemble_tuned.pkl", "rb") as f:
    ensemble_tuned = pickle.load(f)

with open("vectorizer.pkl", "rb") as f:
    vectorizer = pickle.load(f)

# === App Title ===
st.title("💬 Love Island Tweet Sentiment Analysis")
st.write("Analyze public sentiment from tweets about Love Island using NLP and ML models.")

# === Sidebar ===
st.sidebar.header("⚙️ Model Options")
model_choice = st.sidebar.selectbox("Select Model", ["Naive Bayes", "Logistic Regression", "Voting Ensemble"])

# === User Input ===
user_input = st.text_area("Enter a tweet to analyze sentiment:")

if st.button("Analyze Sentiment"):
    if user_input.strip():
        X_input = vectorizer.transform([user_input])

        # Select model
        if model_choice == "Naive Bayes":
            model = best_nb
        elif model_choice == "Logistic Regression":
            model = best_lr
        else:
            model = ensemble_tuned

        # Predict
        pred = model.predict(X_input)[0]

        # 🔍 Debug line - shows the raw model output
        st.write("🧩 Raw prediction from model:", pred)

        # Flexible mapping
        sentiment_map = {
            1: "😊 Positive",
            0: "😐 Neutral",
            -1: "😡 Negative",
            2: "😊 Positive",
            "positive": "😊 Positive",
            "Positive": "😊 Positive",
            "NEGATIVE": "😡 Negative",
            "Negative": "😡 Negative",
            "neutral": "😐 Neutral",
            "Neutral": "😐 Neutral"
        }

        sentiment = sentiment_map.get(pred, "Unknown")
        st.markdown(f"### 🎯 Predicted Sentiment: {sentiment}")

    else:
        st.warning("Please enter a tweet to analyze.")

# === Optional: Word Cloud ===
st.sidebar.header("📊 Word Cloud")
if st.sidebar.button("Show Word Cloud"):
    df = pd.read_excel("love_island_tweets.xlsx")  # your dataset
    text = " ".join(df['clean_tweet'].astype(str))
    wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    st.pyplot(plt)

# === Optional: Sentiment Distribution Chart ===
if st.sidebar.button("Show Sentiment Distribution"):
    df = pd.read_csv("love_island_tweets.csv")
    sentiment_counts = df['Sentiment_label'].value_counts()
    st.bar_chart(sentiment_counts)